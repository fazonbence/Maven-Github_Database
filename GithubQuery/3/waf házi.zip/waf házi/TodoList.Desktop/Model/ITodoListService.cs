﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TodoList.Persistence;
using TodoList.Persistence.DTO;

namespace TodoList.Desktop.Model
{
    public interface ITodoListService
    {
        bool IsUserLoggedIn { get; }
        Task<IEnumerable<ListDto>>  LoadListsAsync();
        Task<IEnumerable<ItemDto>> LoadItemsAsync(Int32 listId);
        Task<bool> LoginAsync(string name, string password);
        Task<bool> RegisterAsync(string name, string password);
        Task<bool> LogoutAsync();
    }
}
